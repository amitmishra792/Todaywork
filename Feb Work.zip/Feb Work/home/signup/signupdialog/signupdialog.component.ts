import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signupdialog',
  templateUrl: './signupdialog.component.html'
})
export class SignupDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
