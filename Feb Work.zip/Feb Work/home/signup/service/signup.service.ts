import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { Observable } from 'rxjs/Observable';
import { RegisterUser } from '../model/register-user';
import { HttpParams } from '@angular/common/http';

@Injectable()
export class SignupService {
   registerUserUrl = 'http://localhost:8081/airline/services/rest/registermanagement/v1/registeruser/saveRegisterUser';
 //  registerUserUrl = 'http://localhost:2019/registerUser/registerUser';
  constructor(private http: Http) {
  }

  // Login User JSON Data Creation and Sent request to server done here
  createUser(registerUser: RegisterUser): any {
    // let Params = new HttpParams();
    //  console.log('email : ', registerUser.email);
    //     console.log('password : ', registerUser.password);
    //        console.log('fullName : ', registerUser.fullName);
    //           console.log('country : ', registerUser.email);
    // Params = Params.append('email', registerUser.email);
    // Params = Params.append('password', registerUser.password);
    // Params = Params.append('fullName', registerUser.fullName);
    // Params = Params.append('country', registerUser.country);
   

    // return this.http.post(this.registerUserUrl, Params)
    //   .map((response: Response) => response).catch(this.handleError);
    let cpHeaders: Headers;
        let options: RequestOptions;
        cpHeaders = new Headers({ 'Content-Type': 'application/json' });
        options = new RequestOptions({ headers: cpHeaders });

      

        return this.http.post(this.registerUserUrl, registerUser, options)
       // .map(success => success.status);
             .map(success => success.status).catch(this.handleError);
  }

  private handleError(error: Response | any) {
         console.log('came here error : ' + error.message);
        console.error(error.message || error);
        return Observable.throw(error.status);
    }
}
