export class RegisterUser {
    constructor(
        public email: string, public password: string,
        public fullName: string, public country: string) {
    }
}

