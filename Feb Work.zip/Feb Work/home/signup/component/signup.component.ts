import { Component, ElementRef, OnInit, ViewChild, Input } from '@angular/core';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SignupService } from './../service/signup.service';
import { RegisterUser } from './../model/register-user';
import { MatDialogModule } from '@angular/material/dialog';

import { MatDialog } from '@angular/material';
import { SignupDialogComponent } from './../signupdialog/signupdialog.component';


import { MatTableDataSource } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { DataSource } from '@angular/cdk/collections';
import { Observable } from 'rxjs/Observable';



import { AUTOCOMPLETE_OPTION_HEIGHT } from '@angular/material';
import { SearchFlightService } from './../../search/service/search-flight.service';

import { FlightInfo } from './../../search/model/flight-info';

import { LoginUserComponent } from './../../login/component/login-user.component';






@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  // Declaration of instance variable
  statusCode: number;
  @ViewChild(SignupDialogComponent) messagePopuoDialogSignUp: SignupDialogComponent;
  @Input() loginStatus: number;
  instance;


  registerUserForm = new FormGroup({
    email: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
    fullName: new FormControl('', Validators.required),
    country: new FormControl('', Validators.required)
  });
  constructor(private registerUserService: SignupService, private dialog: MatDialog) { }
  ngOnInit() {
  }

  // Handle Login User Here
  onRegisterUserFormSubmit() {
    console.log('hello onRegisterUserFormSubmit ');
    let email = '';
    let password = '';
    let fullName = '';
    let country = '';


    email = this.registerUserForm.get('email').value.trim();
    password = this.registerUserForm.get('password').value.trim();
    fullName = this.registerUserForm.get('fullName').value.trim();
    country = this.registerUserForm.get('country').value.trim();

    const registerUser = new RegisterUser( email, password, fullName, country);

    this.registerUserService.createUser(registerUser)
      .subscribe(data => {
      //   this.returnSignUpConformation(data);});
         this.returnSignUpConformation(data);}, errorCode => this.returnSignUpConformation(errorCode));
  }

  // this function check whether user Already login or not
  returnSignUpConformation(abc: any) {
    console.log('came here signup : ' + abc);
    
    this.statusCode = abc;
    if (abc === 200) {
      let dialogRef: any;
      dialogRef = this.dialog.open(SignupDialogComponent);
    }

  }



}
