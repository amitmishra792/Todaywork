import { BookingDialogComponent } from './../booking/bookingdialog/booking-dialog.component';
import { Component, ElementRef, OnInit, Input, ViewChild } from '@angular/core';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { DataSource } from '@angular/cdk/collections';
import { Observable } from 'rxjs/Observable';

import { MatDialog } from '@angular/material';

import { AUTOCOMPLETE_OPTION_HEIGHT } from '@angular/material';
import { SearchFlightService } from './../../search/service/search-flight.service';

import { FlightInfo } from './../../search/model/flight-info';
import { BookingTicketComponent } from './../booking/component/booking-ticket.component';
import { LoginUserComponent } from './../../login/component/login-user.component';

@Component({
  selector: 'app-search-flight-details',
  templateUrl: './search-flight-details.component.html',
  styleUrls: ['./search-flight-details.component.css'],
})
export class SearchFlightDetailsComponent implements OnInit {
  searchUserForm = new FormGroup({
    source: new FormControl('', Validators.required),
    destination: new FormControl('', Validators.required),
    dateOfJourney: new FormControl('', Validators.required)
  });

  @Input() loginStatus: number;
  @Input() loginId: number;
  @ViewChild(BookingTicketComponent) bookingComponent: BookingTicketComponent;
  @ViewChild(LoginUserComponent) loginChildComponent: LoginUserComponent;
  @ViewChild(BookingDialogComponent) messagePopuoDialog: BookingDialogComponent;
  clickEvent: number;

  dataSource;
  displayedColumns;
  selection;
  rowNumber: number;
  rowNumber2: number;
  length;



  // Handle Login User Here
  onSearchUserFormSubmit(): void {

    let source = '';
    let destination = '';
    this.rowNumber = 5;
    source = this.searchUserForm.get('source').value.trim();
    destination = this.searchUserForm.get('destination').value.trim();
    this.dataSource = new UserDataSource(this.searchFlightService, source, destination);
    this.displayedColumns = ['select','flightId', 'flightNumber',
      'flightName', 'source', 'destination', 'price', 'departDate'];
    this.selection = new SelectionModel<FlightInfo>(true, []);
  }



  constructor(private searchFlightService: SearchFlightService, private dialog: MatDialog) {
  }

  ngOnInit() {
  }






  onClickBookTicket(): void {
     console.log('coming in onClick component : ');
    let bookingInfo;
    bookingInfo = this.selection.selected;
    this.length = bookingInfo.length;

    if (this.length !== 1) {
      let dialogRef: any;

      dialogRef = this.dialog.open(BookingDialogComponent);

    } else {
       console.log('coming in else block component : ');
      this.bookingComponent.booking(bookingInfo[0]);
    }
  }



















  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = -1;
    return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }

}

export class UserDataSource extends DataSource<any> {
  source = '';
  destination = '';
  constructor(private searchFlightService: SearchFlightService, source: string,
    destination: string) {
    super();
    this.source = source;
    this.destination = destination;
  }

  connect(): Observable<FlightInfo[]> {
    return this.searchFlightService.searchFlight(this.source, this.destination);
  }

  disconnect() {
  }
}
