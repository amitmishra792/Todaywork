import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { Observable } from 'rxjs/Observable';


// Observable class extensions
import 'rxjs/add/observable/of';
import 'rxjs/add/observable/throw';

// Observable operators
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/filter';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/switchMap';
import { FlightInfo } from './../../model/flight-info';


@Injectable()
export class BookingService {
  bookTicketUrl = 'http://localhost:2019/bookTicket/bookTicket';

  //  loginStatusUrl = 'http://localhost:2019/loginUser/getLoginStatus';
 

  userId;
  constructor(private http: Http) { }

  // Booking Data Sent request to server done here
  bookTicket(flightNumber: string) {
    console.log(' hello service flightNumber: ' + flightNumber);
    let cpHeaders: Headers;
    let options: RequestOptions;
    cpHeaders = new Headers({ 'Content-Type': 'application/json' });
    options = new RequestOptions({ headers: cpHeaders });
    return this.http.post(this.bookTicketUrl, flightNumber, options)
      .map((response: Response) => response);

  }

  // Check User Already Login or Not
  getLoginStatus(): Observable<number> {
    let loginStatusUrl = 'http://localhost:8081/airline/services/rest/searchmanagement/v1/loginstatus/getLoginStatusFromDb';
     console.log('coming in booking service : ');
    let cpHeaders: Headers;
    let options: RequestOptions;
    cpHeaders = new Headers({ 'Content-Type': 'application/json' });
    options = new RequestOptions({ headers: cpHeaders });
    return this.http.get( loginStatusUrl, options)
      .map(success => success.status).catch(this.handleError);
  }

  private handleError(error: Response | any) {
    console.error(error.message || error);
    return Observable.throw(error.status);
  }



}
