import { LoginUserComponent } from './../../../login/component/login-user.component';
import { Component, OnInit, Input, ViewChild } from '@angular/core';

import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SearchFlightService } from './../../service/search-flight.service';
import { FlightInfo } from './../../model/flight-info';
import { BookingService } from './../service/booking.service';
import { BookingDialogComponent } from './../bookingdialog/booking-dialog.component';
import { ConfirmationComponent } from './../../confirm/confirmation.component';



@Component({
  selector: 'app-booking-ticket',
  templateUrl: './booking-ticket.component.html',
  styleUrls: ['./booking-ticket.component.css'],
})
export class BookingTicketComponent implements OnInit {

  var;
  xyz;

  @Input() loginStatus: number;
  @ViewChild(BookingDialogComponent) messagePopuoDialog: BookingDialogComponent;
  @ViewChild(LoginUserComponent) loginComponent: LoginUserComponent;
  @ViewChild(ConfirmationComponent) ticketConformation: ConfirmationComponent;

  constructor(private bookingService: BookingService, private dialog: MatDialog) {
  }

  ngOnInit() {
  }

  booking(flightInfo: FlightInfo) {
    console.log('coming in booking component : ');
    this.bookingService.getLoginStatus().subscribe(data => {
      this.returnLoginStatus(data) }, errorCode => this.returnLoginStatus(errorCode));
      this.var = flightInfo;
  //  let  varValue = this.var;
  //   console.log('Before bboking method : '+ this.var );
  //     if(varValue === 1){
  //     console.log('Inside Booking method in Booking component : ' );
  //    // this.bookingService.bookTicket(flightNumber).subscribe(data => {
  //    // this.returnBookingConformation(data)}, errorCode => this.returnBookingConformation(errorCode));
  //      this.ticketConformation.bookMyTicket(flightNumber);

  //     }
  }


  returnBookingConformation(abc: any) {
     console.log( 'returnBookingConformation in Booking component : ' + abc);
    if (abc.status === 201) {
      let dialogRef: any;
      dialogRef = this.dialog.open(BookingDialogComponent);
    }
  }
   // this function return Login Status
   returnLoginStatus(abc: any) {
     console.log( 'LoginStatus in Booking component : ' + abc);
    if (abc === 204) {
      let dialogRef: any;
      dialogRef = this.dialog.open(LoginUserComponent, {
        height: '400px',
        width: '600px',
      });
    }
    if(abc === 302){
    
      let dialogRef: any;
      this.xyz = 500;
     // this.ticketConformation.bookMyTicket(this.var);
      // dialogRef = this.dialog.open(ConfirmationComponent, {
      //   height: '600px',
      //   width: '750px',
      // });
    }
  }

}
