export class SearchFlight {
    constructor(public source: string, public destination: string,
         public dateOfJourney: string) {
    }
}
