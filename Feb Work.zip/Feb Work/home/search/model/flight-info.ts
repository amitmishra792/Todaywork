export interface FlightInfo {
        flightId: string,
    flightName: string,
    flightNumber: string,
    source: string,
    destination: string,
    price: string,
    departDate: string

}
