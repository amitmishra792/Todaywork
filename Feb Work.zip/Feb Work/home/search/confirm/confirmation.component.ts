import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router} from '@angular/router';
import {MatCardModule} from '@angular/material/card';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FlightInfo } from './../model/flight-info';

@Component({
  selector: 'app-confirmation',
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.css']
})
export class ConfirmationComponent {

   constructor( ) { }


passengerForm = new FormGroup({
    fullName: new FormControl('', Validators.required),
    age: new FormControl('', Validators.required),
    emailId: new FormControl('', Validators.required)
  });

 @Input() fullName;

conformTicketFormSubmit() {
  console.log('coming' );
    let fullName = '';
    let age = '';
    let emailId = '';

    fullName = this.passengerForm.get('fullName').value.trim();
    age = this.passengerForm.get('age').value.trim();
    emailId = this.passengerForm.get('emailId').value.trim();

console.log(age);
console.log(fullName);
console.log(emailId);
    
}

  bookMyTicket( flightInfo: FlightInfo){
    console.log(' Inside Booking ticket : ' +  flightInfo.flightId);
  //  this.gotoTicketDetails();
  }

 

}
