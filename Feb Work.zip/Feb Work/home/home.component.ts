import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
 loginStatus: number;
  
  constructor() { 
    this.loginStatus = 0;
  }

  ngOnInit() {
  }

  changeLoginStatusGlobally(status: any): void {
    this.loginStatus = status;
    console.log("Inside Home Return : " + status);
    this.loginStatus = status;
  }

}
