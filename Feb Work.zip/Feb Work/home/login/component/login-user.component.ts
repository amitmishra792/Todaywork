import { MatDialog } from '@angular/material';
import { MatDialogModule } from '@angular/material/dialog';
import { LoginDialogComponent } from './../logindialog/login-dialog.component';
import { Component, ElementRef, ViewChild,  } from '@angular/core';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';

import { LoginUser } from '../model/login-user';
import { LoginUserService } from '../service/login-user.service';
import { LoginStatus } from './../model/login-status';


@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})

export class LoginUserComponent {

  // Declaration of instance variable
  statusCode;
  val1;
  val2;

userEmail: String; 

  @ViewChild(LoginDialogComponent) loginDialog: LoginDialogComponent;

  loginUserForm = new FormGroup({
    email: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required)
  });

  // Create constructor to get service instance
  constructor(private loginUserService: LoginUserService, private dialog: MatDialog) {
  }

  // Handle Login User Here
  onLoginUserFormSubmit() {
    let email = '';
    let password = '';

    email = this.loginUserForm.get('email').value.trim();
    password = this.loginUserForm.get('password').value.trim();
 
    if(email === ''){
      console.log( 'Inside empty email : ' + email );
     this.val1 = 900;
     return '';
    }else if(password === ''){
       console.log( 'Inside empty password : ' + password );
        this.val1 = 1000;
       this.val2 = 901;
      return '';
    }
      this.val2 = 9000;
      this.userEmail = email;

     let loginUser = new LoginUser(email, password);

     this.loginUserService.loginUser(loginUser)
       .subscribe(data => {
         this.emailIdExist(data);
       }, errorCode => this.emailIdExist(errorCode));
  }

  // this function check whether user Already login or not
  emailIdExist(abc: any) {
    console.log('emailIdExist came here : ' + abc);
    this.statusCode = abc;
    if (abc === 302) {
      console.log('LOGIN Successfully');
    let loginStatus= new LoginStatus(this.userEmail, 'true');

      this.loginUserService.saveLoginStatus(loginStatus ) .subscribe(data => {
         this.loginStatusSaved(data);
       }, errorCode => this.loginStatusSaved(errorCode));
    }

  }

  loginStatusSaved(abcd: any){
    
     console.log('loginStatusSaved came here : ' + abcd);
     if(abcd === 201){
      console.log('loginStatusSaved successfully : ' + abcd);
     }

  }





}
