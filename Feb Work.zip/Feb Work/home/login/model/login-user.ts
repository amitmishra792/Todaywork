export class LoginUser {
    constructor( public email: string, public password: string) {
    }
}
