
export class LoginStatus {
    constructor( public loginStatus: String, public loginEmail: String) {
    }
}
