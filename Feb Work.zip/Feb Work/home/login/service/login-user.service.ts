import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { LoginUser } from '../model/login-user';
import { Observable } from 'rxjs/Observable';
import { LoginStatus } from './../model/login-status';

@Injectable()
export class LoginUserService {

    


    constructor(private http: Http) {
    }

    // Login User JSON Data Creation and Sent request to server done here
    loginUser(loginUser: LoginUser): any {
              let options: RequestOptions;
                let cpHeaders: Headers;
        cpHeaders = new Headers({ 'Content-Type': 'application/json' });
        options = new RequestOptions({ headers: cpHeaders });
       let loginUserUrl = 'http://localhost:8081/airline/services/rest/usermanagement/v1/registeruser/validateUserLogin/';

		return this.http.post(loginUserUrl,loginUser, options).map(success => success.status).catch(this.handleError);
    }


 // Check User Already Login or Not
  saveLoginStatus(loginStatus: LoginStatus): Observable<number> {
      let url = 'http://localhost:8081/airline/services/rest/usermanagement/v1/registeruser/saveLoginStatus/';
    let cpHeaders: Headers;
    let options: RequestOptions;
    cpHeaders = new Headers({ 'Content-Type': 'application/json' });
    options = new RequestOptions({ headers: cpHeaders });
    return this.http.post(url,loginStatus, options)
      .map(success => success.status).catch(this.handleError);
  }

 

    private handleError(error: Response | any) {
        console.error(error.message || error);
        return Observable.throw(error.status);
    }

}
