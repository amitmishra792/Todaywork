import { RouterModule } from '@angular/router';
// Angular Module and Router Dependencies are imported here
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Router } from '@angular/router';
import { Routes } from '@angular/router';


// Angular Form Dependencies are imported here
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { FormArrayName } from '@angular/forms';
import {MatFormFieldModule} from '@angular/material/form-field';


// Material Design Dependencies are imported here
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule, MatToolbarModule } from '@angular/material';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatInputModule } from '@angular/material/input';
import { MatAutocompleteModule } from '@angular/material';
import { MatFormField } from '@angular/material/form-field';
import { MatTableModule } from '@angular/material/table';
import { MatButtonToggleModule, MatDialogModule, MatDialogRef } from '@angular/material';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';


// Component are imported here
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginUserComponent } from './home/login/component/login-user.component';
import { SearchFlightDetailsComponent } from './home/search/component/search-flight-details.component';
import { BookingTicketComponent } from './home/search/booking/component/booking-ticket.component';
import { LoginDialogComponent } from './home/login/logindialog/login-dialog.component';
import { TabComponent } from './home/tab/tab.component';
import { SignupComponent } from './home/signup/component/signup.component';

import { SignupDialogComponent } from './home/signup/signupdialog/signupdialog.component';
  import { BookingDialogComponent } from './home/search/booking/bookingdialog/booking-dialog.component';
    import { ConfirmationComponent } from './home/search/confirm/confirmation.component';
    import { TicketDetailsComponent } from './home/search/ticket/ticket-details.component';



// Service are imported here
import { SearchFlightService } from './home/search/service/search-flight.service';
import { LoginUserService } from './home/login/service/login-user.service';

import { BookingService } from './home/search/booking/service/booking.service';
import { SignupService } from './home/signup/service/signup.service';


// test data
import { CommonModule } from '@angular/common';


import { A11yModule } from '@angular/cdk/a11y';
import { BidiModule } from '@angular/cdk/bidi';
import { ObserversModule } from '@angular/cdk/observers';
import { OverlayModule } from '@angular/cdk/overlay';
import { PlatformModule } from '@angular/cdk/platform';
import { PortalModule } from '@angular/cdk/portal';
import { ScrollDispatchModule } from '@angular/cdk/scrolling';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTableModule } from '@angular/cdk/table';
import {
  MatChipsModule,
  MatDatepickerModule,
  MatExpansionModule,
  MatGridListModule,
  MatListModule,
  MatNativeDateModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatStepperModule,
  MatTabsModule,
  MatTooltipModule,
} from '@angular/material';


const routes: Routes = [
  // map '/persons' to the people list component
  {
    path: 'ticketDetails',
    component: TicketDetailsComponent,
  }, ];

  export const appRouterModule = RouterModule.forRoot(routes);


@NgModule({
  exports: [
    // CDK
    A11yModule,
    BidiModule,
    ObserversModule,
    OverlayModule,
    PlatformModule,
    PortalModule,
    ScrollDispatchModule,
    CdkStepperModule,
    CdkTableModule,

    // Material
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSlideToggleModule,
    MatSliderModule,
    MatSnackBarModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatNativeDateModule,
    MatFormFieldModule,
    RouterModule
  ],
  declarations: [LoginDialogComponent, TabComponent, SignupComponent, BookingDialogComponent, SignupDialogComponent, ConfirmationComponent]
})
export class MaterialModule { }

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginUserComponent,
    SearchFlightDetailsComponent,
    BookingTicketComponent,
    TabComponent,
    SignupComponent,
    BookingDialogComponent,
    SignupDialogComponent,
    LoginDialogComponent,
    ConfirmationComponent
  ],
  imports: [
  BrowserModule, BrowserAnimationsModule, MatCheckboxModule, MatCardModule, MatButtonModule, MatIconModule,
    MatMenuModule, MatToolbarModule, MatInputModule, ReactiveFormsModule, HttpModule, HttpClientModule,
    MatTableModule, MatDialogModule, MatTabsModule, MatTooltipModule, MatFormFieldModule ],
  providers: [LoginUserService, SearchFlightService, BookingService, SignupService],
  bootstrap: [AppComponent],
  entryComponents: [BookingDialogComponent, SignupDialogComponent, LoginDialogComponent, LoginUserComponent, ConfirmationComponent],

})
export class AppModule { }
