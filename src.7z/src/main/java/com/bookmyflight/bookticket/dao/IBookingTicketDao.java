package com.bookmyflight.bookticket.dao;


public interface IBookingTicketDao {

	void bookingTicket(String flightNumber);

}
