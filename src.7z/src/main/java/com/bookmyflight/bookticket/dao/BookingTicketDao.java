package com.bookmyflight.bookticket.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bookmyflight.bookticket.entity.BookingInfo;

@Transactional
@Repository
public class BookingTicketDao implements IBookingTicketDao {
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void bookingTicket(String flightNumber) {
		BookingInfo booking = new BookingInfo();
		booking.setFlightNumber(flightNumber);
		
		

		this.entityManager.persist(booking);
	}

}
