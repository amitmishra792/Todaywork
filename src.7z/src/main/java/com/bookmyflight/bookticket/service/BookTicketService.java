package com.bookmyflight.bookticket.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookmyflight.bookticket.dao.IBookingTicketDao;

@Service
public class BookTicketService implements IBookTicketService {
  @Autowired
  private IBookingTicketDao bookingTicketdao;

  @Override
  public synchronized boolean bookingTicket(String flightNumber) {

    this.bookingTicketdao.bookingTicket(flightNumber);
    return true;

  }

}
