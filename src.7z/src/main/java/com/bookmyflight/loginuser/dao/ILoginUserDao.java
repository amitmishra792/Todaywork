package com.bookmyflight.loginuser.dao;

import com.bookmyflight.loginuser.entity.LoginUser;

public interface ILoginUserDao {

  void loginAlreadyRegUser(LoginUser loginUser);

}
