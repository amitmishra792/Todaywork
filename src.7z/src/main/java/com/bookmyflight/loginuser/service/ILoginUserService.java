package com.bookmyflight.loginuser.service;

import com.bookmyflight.loginuser.entity.LoginUser;

public interface ILoginUserService {

  boolean loginAlreadyRegUser(LoginUser user);

}
