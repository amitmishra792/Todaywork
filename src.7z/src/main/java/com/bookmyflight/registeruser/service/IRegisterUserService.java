package com.bookmyflight.registeruser.service;

import org.springframework.stereotype.Service;

@Service
public interface IRegisterUserService  {


 boolean createUser(String email, String password, String fullName, String country);

  

}
