package com.bookmyflight.registeruser.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bookmyflight.registeruser.dao.IRegisterUserDao;

@Service
public class RegisterUserService implements IRegisterUserService {
  @Autowired
  private IRegisterUserDao registerUserDao;

  @Override
  public synchronized boolean createUser(String email, String password, String fullName, String country) {

    this.registerUserDao.createUser(email, password, fullName, country);
    return true;

  }

}
