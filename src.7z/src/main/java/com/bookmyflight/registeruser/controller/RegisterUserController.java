package com.bookmyflight.registeruser.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.util.UriComponentsBuilder;

import com.bookmyflight.registeruser.service.IRegisterUserService;

@Controller
@RequestMapping("registerUser")
@CrossOrigin(origins = { "http://localhost:4200" })
public class RegisterUserController {

	@Autowired
	private IRegisterUserService registerUserService;

	@PostMapping("registerUser")
	public ResponseEntity<Void> createUser( String email, String password, String fullName, String country, UriComponentsBuilder builder) {
		System.out.println(" Register UserController : ");
		
		
		boolean flag = this.registerUserService.createUser( email, password, fullName, country);
		if (flag == false) {
			return new ResponseEntity<Void>(HttpStatus.CONFLICT);
		}
		System.out.println(">>>>>>>>>>>>" + flag);
		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(builder.path("/registerUser?email={email}")
				.buildAndExpand(email).toUri());
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);

	}

}