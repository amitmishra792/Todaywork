// Angular Module and Router Dependencies are imported here
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Router } from '@angular/router';

// Angular Form Dependencies are imported here
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { FormArrayName } from '@angular/forms';

// Material Design Dependencies are imported here
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule, MatToolbarModule } from '@angular/material';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatInputModule } from '@angular/material/input';
import { MatAutocompleteModule } from '@angular/material';
import { MatFormField } from '@angular/material/form-field';
import { MatTableModule } from '@angular/material/table';
import { MatButtonToggleModule, MatDialogModule, MatDialogRef } from '@angular/material';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';


// Component are imported here
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginUserComponent } from './home/login/component/login-user.component';
import { SearchFlightDetailsComponent } from './home/search/component/search-flight-details.component';
import { BookingTicketComponent } from './home/search/booking/component/booking-ticket.component';
import { UtilComponent } from './home/login/util/util.component';
import { TabComponent } from './home/tab/tab.component';
import { SignupComponent } from './home/signup/component/signup.component';
import { DialogmessageComponent } from './home/search/dialogmessage/dialogmessage.component';
import { SignupdialogComponent } from './home/signup/signupdialog/signupdialog.component';




// Service are imported here
import { SearchFlightService } from './home/search/service/search-flight.service';
import { LoginUserService } from './home/login/service/login-user.service';

import { BookingService } from './home/search/booking/service/booking.service';
import { SignupService } from './home/signup/service/signup.service';


// test data
import { CommonModule } from '@angular/common';


import { A11yModule } from '@angular/cdk/a11y';
import { BidiModule } from '@angular/cdk/bidi';
import { ObserversModule } from '@angular/cdk/observers';
import { OverlayModule } from '@angular/cdk/overlay';
import { PlatformModule } from '@angular/cdk/platform';
import { PortalModule } from '@angular/cdk/portal';
import { ScrollDispatchModule } from '@angular/cdk/scrolling';
import { CdkStepperModule } from '@angular/cdk/stepper';
import { CdkTableModule } from '@angular/cdk/table';
import {
  MatChipsModule,
  MatDatepickerModule,
  MatExpansionModule,
  MatGridListModule,
  MatListModule,
  MatNativeDateModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatStepperModule,
  MatTabsModule,
  MatTooltipModule,
} from '@angular/material';


@NgModule({
  exports: [
    // CDK
    A11yModule,
    BidiModule,
    ObserversModule,
    OverlayModule,
    PlatformModule,
    PortalModule,
    ScrollDispatchModule,
    CdkStepperModule,
    CdkTableModule,

    // Material
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSlideToggleModule,
    MatSliderModule,
    MatSnackBarModule,
    MatStepperModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatNativeDateModule,
  ],
  declarations: [UtilComponent, TabComponent, SignupComponent, DialogmessageComponent, SignupdialogComponent]
})
export class MaterialModule { }

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginUserComponent,
    SearchFlightDetailsComponent,
    BookingTicketComponent,
    TabComponent,
    SignupComponent,
    DialogmessageComponent,
    SignupdialogComponent,
    UtilComponent
  ],
  imports: [
    BrowserModule, BrowserAnimationsModule, MatCheckboxModule, MatCardModule, MatButtonModule, MatIconModule,
    MatMenuModule, MatToolbarModule, MatInputModule, ReactiveFormsModule, HttpModule, HttpClientModule,
    MatTableModule, MatDialogModule, MatTabsModule
  ],
  providers: [MatIconModule, LoginUserService, SearchFlightService, BookingService, SignupService],
  bootstrap: [AppComponent],
  entryComponents: [DialogmessageComponent, SignupdialogComponent, UtilComponent],

})
export class AppModule { }
