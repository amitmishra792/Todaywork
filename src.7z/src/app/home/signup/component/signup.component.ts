import { Component, ElementRef, OnInit, ViewChild, Input } from '@angular/core';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SignupService } from './../service/signup.service';
import { RegisterUser } from './../model/register-user';
import { MatDialogModule } from '@angular/material/dialog';

import { MatDialog } from '@angular/material';
import { SignupdialogComponent } from './../signupdialog/signupdialog.component';


import { MatTableDataSource } from '@angular/material';
import { SelectionModel } from '@angular/cdk/collections';
import { DataSource } from '@angular/cdk/collections';
import { Observable } from 'rxjs/Observable';



import { AUTOCOMPLETE_OPTION_HEIGHT } from '@angular/material';
import { SearchFlightService } from './../../search/service/search-flight.service';

import { FlightInfo } from './../../search/model/flight-info';

import { LoginUserComponent } from './../../login/component/login-user.component';






@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  // Declaration of instance variable
  statusCode: number;
  @ViewChild(SignupdialogComponent) messagePopuoDialogSignUp: SignupdialogComponent;
  @Input() loginStatus: number;
  instance;


  registerUserForm = new FormGroup({
    email: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
    fullName: new FormControl('', Validators.required),
    country: new FormControl('', Validators.required)
  });
  constructor(private registerUserService: SignupService, private dialog: MatDialog) { }
  ngOnInit() {
  }

  // Handle Login User Here
  onRegisterUserFormSubmit() {
    console.log('hello onRegisterUserFormSubmit ');
    let email = '';
    let password = '';
    let userId = '';
    let fullName = '';
    let country = '';


    email = this.registerUserForm.get('email').value.trim();
    password = this.registerUserForm.get('password').value.trim();
    fullName = this.registerUserForm.get('fullName').value.trim();
    country = this.registerUserForm.get('country').value.trim();

    userId = '';
    const registerUser = new RegisterUser(userId, email, password, fullName, country);

    this.registerUserService.createUser(registerUser)
      .subscribe(data => {
        this.returnBookingConformation(data);
      });
  }

  // this function check whether user Already login or not
  returnBookingConformation(abc: any) {
    if (abc.status === 201) {

      let dialogRef = this.dialog.open(SignupdialogComponent);
      let instance = dialogRef.componentInstance;
      instance.text = "You have successfully Registered ";

    } else {
      this.loginStatus = 1;
    }

  }



}
