import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { Response, Headers, URLSearchParams, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { Observable } from 'rxjs/Observable';
import { RegisterUser } from '../model/register-user';
import { HttpParams } from '@angular/common/http';

@Injectable()
export class SignupService {
  registerUserUrl = 'http://localhost:2019/registerUser/registerUser';
  constructor(private http: Http) {
  }

  // Login User JSON Data Creation and Sent request to server done here
  createUser(registerUser: RegisterUser): any {
    let Params = new HttpParams();
    Params = Params.append('email', registerUser.email);
    Params = Params.append('password', registerUser.country);
    Params = Params.append('fullName', registerUser.fullName);
    Params = Params.append('country', registerUser.country);

    return this.http.post(this.registerUserUrl, Params)
      .map((response: Response) => response);
  }
}
