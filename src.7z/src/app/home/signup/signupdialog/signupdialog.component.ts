import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-signupdialog',
  templateUrl: './signupdialog.component.html'
})
export class SignupdialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

text;
}
