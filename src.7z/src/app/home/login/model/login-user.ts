export class LoginUser {
    constructor(public userId: string, public email: string, public password: string) {
    }
}
