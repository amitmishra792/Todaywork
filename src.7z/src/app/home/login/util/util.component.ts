import { Component, OnInit, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-util',
  templateUrl: './util.component.html',
  styleUrls: ['./util.component.css']
})
export class UtilComponent implements OnInit {

   text;

  constructor() { }

  ngOnInit() {

  }
 



}
