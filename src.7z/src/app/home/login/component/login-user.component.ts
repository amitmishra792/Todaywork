import { Component, ElementRef, Input, ViewChild } from '@angular/core';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';

import { LoginUser } from '../model/login-user';
import { LoginUserService } from '../service/login-user.service';
import { UtilComponent } from './../util/util.component';
import { MatDialog } from '@angular/material';


@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css'],

})

export class LoginUserComponent {
   @ViewChild(UtilComponent) utilChildComponent: UtilComponent;

  // Declaration of instance variable
  @Input() loginStatus: number;
  loginId;
  xyz;
 

  hideLoginComponent: number;

  loginUserForm = new FormGroup({
    email: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required)
  });

  // Create constructor to get service instance
  constructor(private loginUserService: LoginUserService, private dialog: MatDialog) {
  }

  // Handle Login User Here
  onLoginUserFormSubmit() {
    let email = '';
    let password = '';
    let userId = '';

    email = this.loginUserForm.get('email').value.trim();
    password = this.loginUserForm.get('password').value.trim();
    this.loginId = email;
    const loginUser = new LoginUser(userId, email, password);

    this.loginUserService.loginUser(loginUser).subscribe(data => {
      this.alreadyLogin(data);
    });
  }



  // this function check whether user Already login or not
  alreadyLogin(abc: any) {
    if (abc.status === 201) {

       let dialogRef = this.dialog.open(UtilComponent);
      let instance = dialogRef.componentInstance;
      instance.text = "You are Login successfully ";
    } 
  }



}
