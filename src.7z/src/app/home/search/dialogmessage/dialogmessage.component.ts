import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dialogmessage',
  templateUrl: './dialogmessage.component.html',
  styleUrls: ['./dialogmessage.component.css']
})
export class DialogmessageComponent implements OnInit {
text;
  constructor() { }

  ngOnInit() {
  }

}
