export class RegisterUser {
    constructor(public userId: string,
        public email: string, public password: string,
        public fullName: string, public country: string) {
    }
}

