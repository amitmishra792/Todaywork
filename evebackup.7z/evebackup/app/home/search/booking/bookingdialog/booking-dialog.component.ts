import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booking-dialog',
  templateUrl: './booking-dialog.component.html',
  styleUrls: ['./booking-dialog.component.css']
})
export class BookingDialogComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
