import { Component, OnInit, Input, ViewChild } from '@angular/core';

import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { SearchFlightService } from './../../service/search-flight.service';
import { FlightInfo } from './../../model/flight-info';
import { BookingService } from './../service/booking.service';
import { BookingDialogComponent } from './../bookingdialog/booking-dialog.component';



@Component({
  selector: 'app-booking-ticket',
  templateUrl: './booking-ticket.component.html',
  styleUrls: ['./booking-ticket.component.css'],
})
export class BookingTicketComponent {

  @Input() loginStatus: number;
  @ViewChild(BookingDialogComponent) messagePopuoDialog: BookingDialogComponent;

  constructor(private bookingService: BookingService, private dialog: MatDialog) {
  }

  ngOnInit() {
  }

  booking(flightNumber: string) {
    this.bookingService.bookTicket(flightNumber).subscribe(data => {
      this.returnBookingConformation(data);
    });
  }

  // this function check whether user Already login or not
  returnBookingConformation(abc: any) {
    if (abc.status === 201) {
      let dialogRef = this.dialog.open(BookingDialogComponent);
    }
  }

}
