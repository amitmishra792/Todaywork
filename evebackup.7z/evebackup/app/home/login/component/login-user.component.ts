import { MatDialog } from '@angular/material';
import { MatDialogModule } from '@angular/material/dialog';
import { LoginDialogComponent } from './../logindialog/login-dialog.component';
import { Component, ElementRef, ViewChild } from '@angular/core';
import { FormControl, FormBuilder, FormGroup, Validators } from '@angular/forms';

import { LoginUser } from '../model/login-user';
import { LoginUserService } from '../service/login-user.service';


@Component({
  selector: 'app-login-user',
  templateUrl: './login-user.component.html',
  styleUrls: ['./login-user.component.css']
})

export class LoginUserComponent {

  // Declaration of instance variable
  statusCode;
  @ViewChild(LoginDialogComponent) loginDialog: LoginDialogComponent;

  loginUserForm = new FormGroup({
    email: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required)
  });

  // Create constructor to get service instance
  constructor(private loginUserService: LoginUserService, private dialog: MatDialog) {
  }

  // Handle Login User Here
  onLoginUserFormSubmit() {
    let email = '';
    let password = '';
    let userId = '';


    email = this.loginUserForm.get('email').value.trim();
    password = this.loginUserForm.get('password').value.trim();
    userId = '';
    const loginUser = new LoginUser(userId, email, password);

    this.loginUserService.loginUser(loginUser)
      .subscribe(data => {
        this.returnLoginConformation(data);
      }, errorCode => this.returnLoginConformation(errorCode));
  }

  // this function check whether user Already login or not
  returnLoginConformation(abc: any) {
    console.log('came here : ' + abc);
    this.statusCode = abc;
    if (abc === 201) {
      console.log('came here');
      let dialogRef: any;
      dialogRef = this.dialog.open(LoginDialogComponent);
    }

  }

}
