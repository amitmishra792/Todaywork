package com.bookmyflight.bookticket.service;


public interface IBookTicketService {

	boolean bookingTicket(String flightNumber);

}
