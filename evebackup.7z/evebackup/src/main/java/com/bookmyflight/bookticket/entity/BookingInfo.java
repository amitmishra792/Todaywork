package com.bookmyflight.bookticket.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BookingInfo")
public class BookingInfo implements Serializable  {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "BOOKING_ID")
	private int bookingId;

	@Column(name = "FLIGHT_NUMBER")
	private String flightNumber;

	public int getBookingId() {
		return bookingId;
	}

	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}

	public String getFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(String flightNumber) {
		this.flightNumber = flightNumber;
	}

	public BookingInfo(int bookingId, String flightNumber) {
		super();
		this.bookingId = bookingId;
		this.flightNumber = flightNumber;
	}

	@Override
	public String toString() {
		return "BookingInfo [bookingId=" + bookingId + ", flightNumber="
				+ flightNumber + "]";
	}

	public BookingInfo() {

	}

}
