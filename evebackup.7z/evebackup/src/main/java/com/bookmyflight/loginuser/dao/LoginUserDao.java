package com.bookmyflight.loginuser.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bookmyflight.loginuser.entity.LoginUser;


@Transactional
@Repository
public class LoginUserDao implements ILoginUserDao {
  @PersistenceContext
  private EntityManager entityManager;

  @Override
  public boolean loginAlreadyRegUser(LoginUser user) {
	  
	  String hql = "From RegisterUser as user WHERE user.email = ?";
		int count = entityManager.createQuery(hql).setParameter(1, user.getEmail()).getResultList().size();
		System.out.println("count : " +  count);
		return count > 0 ? true : false;
  }

}
