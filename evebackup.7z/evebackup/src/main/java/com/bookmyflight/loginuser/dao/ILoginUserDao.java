package com.bookmyflight.loginuser.dao;

import com.bookmyflight.loginuser.entity.LoginUser;

public interface ILoginUserDao {

 public boolean loginAlreadyRegUser(LoginUser loginUser);

}
