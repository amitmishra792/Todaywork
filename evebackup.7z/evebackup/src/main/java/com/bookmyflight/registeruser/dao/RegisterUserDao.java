package com.bookmyflight.registeruser.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bookmyflight.registeruser.entity.RegisterUser;

@Transactional
@Repository
public class RegisterUserDao implements IRegisterUserDao {
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void createUser(String email, String password, String fullName,
			String country) {

		RegisterUser registerUser = new RegisterUser();
		registerUser.setEmail(email);
		registerUser.setCountry(country);
		registerUser.setFullName(fullName);
		registerUser.setPassword(password);

		this.entityManager.persist(registerUser);
	}

}
