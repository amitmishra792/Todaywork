package com.bookmyflight.registeruser.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.util.UriComponentsBuilder;

import com.bookmyflight.registeruser.entity.RegisterUser;
import com.bookmyflight.registeruser.service.IRegisterUserService;
import com.bookmyflight.util.EmailValidator;

@Controller
@RequestMapping("registerUser")
@CrossOrigin(origins = { "http://localhost:4200" })
public class RegisterUserController {

	@Autowired
	private IRegisterUserService registerUserService;

	private EmailValidator emailValidator;

	@PostMapping("registerUser")
	public ResponseEntity<Void> createUser(@RequestBody RegisterUser registerUser, UriComponentsBuilder builder) {
		System.out.println(" Register UserController : ");

		System.out.println("Registration Email : " + registerUser.getEmail());
		emailValidator = new EmailValidator();

		boolean valid = emailValidator.validate( registerUser.getEmail());
		if (valid == false) {
			return new ResponseEntity<Void>(HttpStatus.RESET_CONTENT);
		}

		boolean flag = this.registerUserService.createUser( registerUser.getEmail(),  registerUser.getPassword(),
				 registerUser.getPassword(),  registerUser.getCountry());
		if (flag == false) {
			return new ResponseEntity<Void>(HttpStatus.CONFLICT);
		}
		System.out.println(">>>>>>>>>>>>" + flag);
		HttpHeaders headers = new HttpHeaders();
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);

	}

	public IRegisterUserService getRegisterUserService() {
		return registerUserService;
	}

	public void setRegisterUserService(IRegisterUserService registerUserService) {
		this.registerUserService = registerUserService;
	}

	public EmailValidator getEmailValidator() {
		return emailValidator;
	}

	public void setEmailValidator(EmailValidator emailValidator) {
		this.emailValidator = emailValidator;
	}

}