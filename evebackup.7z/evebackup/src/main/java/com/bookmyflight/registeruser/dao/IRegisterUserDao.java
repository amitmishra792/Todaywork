package com.bookmyflight.registeruser.dao;


public interface IRegisterUserDao {

	void createUser(String email, String password, String fullName, String country);

}
